The BUS_Combined folder contains two folders, "folds", and "imgs" folders and two files, "readme.txt", and "BUS_Combined.csv" files. 
The "folds" folder contains five sub folders where each contains "train.csv", "test.csv", and "valid.csv" files. 
The "imgs" folder contains total of 3,641 BUS images that is built from combining the five datasets.
The "BUS_Combined.csv" contains the tumor id, BUS images names, and the tumor types. 
The "train.csv", "test.csv", and "valid.csv" files in each sub folder in "folds" folder contains a predefined BUS images names and their tumor types. 
  