Note: The raw images of HMSS dataset can be found on: https://www.ultrasoundcases.info/
1. To download the complete HMSS dataset, please run the "Download_HMSS.ipynb" script.

2.The 'Benchmark/Datasets/HMSS/imgs/' folder contains images from HMSS dataset; 
and the HMSS.csv file under 'Benchmark/Datasets/HMSS/' contains information of each image, e.g., image url, image lable, image ID.

3. Under the 'Benchmark/Datasets/HMSS/imgs/' folder, image with a name format 'xxxx.jpg' is raw image, and format 'xxxx_crop.jpg' is the cropped image.