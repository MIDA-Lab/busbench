1. To download the Dataset B, please go to this website:
 http://www2.docm.mmu.ac.uk/STAFF/m.yap/dataset.php, and fill in the Licence 
 Agreement and send to M.Yap@mmu.ac.uk or robert.marti@udg.edu.
  Once approved they will send access information for you to download the dataset.

2.Put all raw ultrasound images under the 'Benchmark/Datasets/DatasetB/imgs/' folder, 
the sementation ground truths under the 'Benchmark/Datasets/DatasetB/GT/' folder, 
and the DatasetB.xlsx file under 'Benchmark/Datasets/DatasetB/'.