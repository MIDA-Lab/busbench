1. To download the BUSIS dataset, please go to this website: http://cvprip.cs.usu.edu/busbench/index.html, and fill in the Licence Agreement and send to hengda.cheng@usu.edu or mxian@uidaho.edu. Once approved they will send access information for you to download the dataset.

2. Put all raw ultrasound images under the 'Benchmark/Datasets/BUSIS/imgs/' folder, the sementation ground truths under the 'Benchmark/Datasets/BUSIS/GT/' folder.

3. 'BUSIS.xlsx' under the 'Benchmark/Datasets/BUSIS/' contains tumor type information.