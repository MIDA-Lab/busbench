Note: The raw images of Thammasat dataset can be found on: http://www.onlinemedicalimages.com/
1. To download the complete Thammasat dataset, please run the "Download_Thammasat.ipynb" script.

2.The Thammasat images are saved under the 'Benchmark/Datasets/Thammasat/imgs/' folder, 
and the Thammasat.csv file under 'Benchmark/Datasets/Thammasat/'