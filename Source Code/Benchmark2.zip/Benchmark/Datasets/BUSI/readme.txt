1. To download the BUSI dataset, please go to this website:
 https://scholar.cu.edu.eg/?q=afahmy/pages/dataset, and follow the instructions.

2. Unzip the BUSI dataset file and put "Benchmark/Datasets/BUSI/benign" and "Benchmark/Datasets/BUSI/malignant" folders under the 'Benchmark/Datasets/BUSI/' folder.

